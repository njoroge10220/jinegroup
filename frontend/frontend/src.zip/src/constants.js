
export const ACCESS_TOKEN = "access";
export const REFRESH_TOKEN = "REFRESH";

/** This will allow for use of local storage in the browser to store access and refresh tokens
in the browser and the two exports will be the keys **/